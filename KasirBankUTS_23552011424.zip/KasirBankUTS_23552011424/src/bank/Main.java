package bank;

import bank.model.*;
import bank.transaksi.Transaksi;

public class Main {
    public static void main(String[] args) {
        Rekening rekening1 = new Tabungan("R001", 1000000);
        Nasabah nasabah1 = new Nasabah("N001", "Andi", rekening1);

        nasabah1.tampilInfo();
        rekening1.setor(500000);
        Transaksi t1 = new Transaksi("Setor", 500000);
        t1.tampilInfo();

        rekening1.tarik(300000);
        Transaksi t2 = new Transaksi("Tarik", 300000);
        t2.tampilInfo();

        System.out.println("Bunga yang didapat: Rp" + rekening1.hitungBunga());
        nasabah1.tampilInfo();
    }
}
