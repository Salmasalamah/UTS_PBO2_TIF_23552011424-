package bank.service;

public interface LayananKeuangan {
    void setor(double jumlah);
    void tarik(double jumlah);
}
