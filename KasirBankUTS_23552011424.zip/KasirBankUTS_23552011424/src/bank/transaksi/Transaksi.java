package bank.transaksi;

import java.util.Date;

public class Transaksi {
    private String tipe;
    private double jumlah;
    private Date tanggal;

    public Transaksi(String tipe, double jumlah) {
        this.tipe = tipe;
        this.jumlah = jumlah;
        this.tanggal = new Date();
    }

    public void tampilInfo() {
        System.out.println("Transaksi: " + tipe + " | Jumlah: Rp" + jumlah + " | Tanggal: " + tanggal);
    }
}
