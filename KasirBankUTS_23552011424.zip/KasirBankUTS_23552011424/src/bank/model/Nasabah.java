package bank.model;

public class Nasabah {
    private String id;
    private String nama;
    private Rekening rekening;

    public Nasabah(String id, String nama, Rekening rekening) {
        this.id = id;
        this.nama = nama;
        this.rekening = rekening;
    }

    public void tampilInfo() {
        System.out.println("Nasabah: " + nama + " | ID: " + id);
        rekening.tampilInfo();
    }

    public Rekening getRekening() {
        return rekening;
    }
}
