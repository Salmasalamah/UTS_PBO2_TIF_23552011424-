package bank.model;

public class Giro extends Rekening {
    public Giro(String id, double saldo) {
        super(id, "Giro", saldo);
    }

    @Override
    public double hitungBunga() {
        return saldo * 0.005; // Bunga 0.5%
    }

    @Override
    public void setor(double jumlah) {
        saldo += jumlah;
        System.out.println("Setor Giro: Rp" + jumlah);
    }

    @Override
    public void tarik(double jumlah) {
        saldo -= jumlah;
        System.out.println("Tarik Giro: Rp" + jumlah);
    }
}
