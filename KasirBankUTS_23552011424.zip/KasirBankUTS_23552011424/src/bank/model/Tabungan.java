package bank.model;

public class Tabungan extends Rekening {
    public Tabungan(String id, double saldo) {
        super(id, "Tabungan", saldo);
    }

    @Override
    public double hitungBunga() {
        return saldo * 0.01; // Bunga 1%
    }

    @Override
    public void setor(double jumlah) {
        saldo += jumlah;
        System.out.println("Setor Tabungan: Rp" + jumlah);
    }

    @Override
    public void tarik(double jumlah) {
        if (jumlah <= saldo) {
            saldo -= jumlah;
            System.out.println("Tarik Tabungan: Rp" + jumlah);
        } else {
            System.out.println("Saldo tidak cukup.");
        }
    }
}
