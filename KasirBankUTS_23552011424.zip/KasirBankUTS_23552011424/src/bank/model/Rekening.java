package bank.model;

import bank.service.LayananKeuangan;

public abstract class Rekening implements LayananKeuangan {
    protected String id;
    protected String jenis;
    protected double saldo;

    public Rekening(String id, String jenis, double saldo) {
        this.id = id;
        this.jenis = jenis;
        this.saldo = saldo;
    }

    public abstract double hitungBunga();

    public double getSaldo() {
        return saldo;
    }

    public String getId() {
        return id;
    }

    public String getJenis() {
        return jenis;
    }

    public void tampilInfo() {
        System.out.println("Rekening: " + id + " | Jenis: " + jenis + " | Saldo: Rp" + saldo);
    }
}
